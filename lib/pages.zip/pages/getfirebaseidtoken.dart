import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// Возвращает актуальный Firebase ID-token.
/// Если пользователь не вошёл в систему – вернётся null.
Future<String?> getFirebaseIdToken() async {
  final user = FirebaseAuth.instance.currentUser; // текущий юзер
  if (user == null) {
    return null; // не авторизован
  }

  // Можно форсировать обновление токена (true), чтобы получить самый свежий
  return await user.getIdToken(); // или getIdToken(true)
}

Future<String?> fetchTokenFromFirestore(String uid) async {
  try {
    DocumentSnapshot snapshot = await FirebaseFirestore.instance
        .collection('user_tokens')
        .doc(uid)
        .get();

    if (!snapshot.exists) {
      return null; // Документ не найден
    }

    Map<String, dynamic>? data = snapshot.data() as Map<String, dynamic>? ?? {};
    return data['token']; // Читаем токен из документа
  } catch (e) {
    print('Error fetching token: $e');
    return null;
  }
}
